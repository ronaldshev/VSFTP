ronald shevchenko . n01385011
cot3210 . project 1 . vsftp

how to compile: when in the proper directory, in two separate command prompts,
                type "javac client.java" and "javac server.java" respectively.
                this will compile the programs.

how to run: in two separate command prompts, type "java server" FIRST in the
            first command prompt and then "java client". this will allow for
            the client to connect to the server. continue by typing the proper
            commands into the command prompt client was run on.
